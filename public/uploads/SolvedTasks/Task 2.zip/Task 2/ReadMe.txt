Factors to take into consideration:

1- Add comments in you code to make it more readable.


Points you need to search about it:

2- Fieldset
3- Legend
4- Input types: date and file
5- Select and option