/*
Write a program to print: 
"Your Grade is A+" if the score is betweem 90 and 100
"Your Grade is B+" if the score is between 80 and 90
"Your Grade is C" if the score is between 50 and 80 
"You failed" if the score is less than 50
*/


// let result = prompt('Enter your grade'),
// Excellent = "Your Grade is A+",
// VeryGood = "Your Grade is B+",
// Good = "Your Grade is C",
// Fail = "You Failed";
//     if(result >= 90 && result <=100){
//         document.write(Excellent);
//     }else if(result >= 80 && result < 90){
//         document.write(VeryGood);
//     }else if(result >= 50 && result < 80){
//         document.write(Good);
//     }else{
//         document.write(Fail);
//     }

/*-----------------------------------------------------------------------------------------------------------------------*/

/*
Write a program which has a variable:
"runner" which equals to your name.
"position" which by default equals to 1.
"medal"
then use if condition to determine which medal you recieved. 
if your position is 1 then you recieved gold medal,
if your position is 2 then you recieved silver medal,
if your position is 3 then you recieved bronze medal.
then use concatenation to print the message: runner received a medal medal.
*/

// let runner ="Amany",
// position = 3,
// medal = "";

// if(position == 1){
//     medal = "Gold";
//     document.write(runner + " recieved a " + medal + " medal.");
// }else if(position == 2){
//     medal = "Silver";
//     document.write(runner + " recieved a " + medal + " medal.");
// }else if(position == 3){
//     medal = "Bronze";
//     document.write(runner + " recieved a " + medal + " medal.");
// }else{
//     document.write("Hard luck!");
// }

/*-----------------------------------------------------------------------------------------------------------------------*/

/*
Write a program which has a variable:
"falvor" which by default sets to Chocolate,
"vessel" which by default sets to Cone,
"toppings" which by default sete to sprinkles.
and the following conditions:
if flavor is set to vanilla or chocolate and if vessel is set to cone or bowl and if toppings is set to sprinkles or peanuts
If the above conditions are true, then print out to the console:
“I'd like two scoops of "flavor" ice cream in a "vessel"  with "toppings" .”
Fill in the blanks with the value of ice cream flavor, vessel, and toppings. 
*/

// var flavor = "Chocolate",
// vessel = "cone",
// toppings = "sprinkles";

// if(flavor == "vanilla" || flavor == "Chocolate" && vessel == "cone" || vessel == "bowl" && toppings == "sprinkles" || toppings == "peanuts") {
//     console.log("I'd like two scoops of " + flavor + " ice cream in a " + vessel + " with " + toppings);
// }













// let flavor ="Vanila",
// vessel = "bowl",
// toppings = "peanuts";
// if((flavor == 'chocolate' || flavor == "Vanila") && (vessel == "cone" || vessel == "bowl") && (toppings == "sprinkles" || toppings == "peanuts")){
//     document.write("I'd like two scoops of " + flavor + " ice cream " + vessel + " with " + toppings);
// }else{
//     document.write("Sorry");
// }

/*-----------------------------------------------------------------------------------------------------------------------*/

/*
let money = 100.50;
let price = 100.50;
write an If..else statement that can compare the money paid and price required using the given amounts above, so it can show to the user one of the three messages detailed below:
"You paid extra, here's your change."	
"You paid the exact amount, have a nice day!"
"That's not enough, you still owe me money."
Hint: you can change the values of money and price to test the different conditions of your if statement. 
You can use a variable called message to print it to the console when any of the conditions is applied.
*/

var money = 100,
price = 200,
Owe = price - money,
Change = money - price;

if(money == price) {
    document.write("You paid the exact amount, have a nice day!");
}else if(price > money){
    document.write("That's not enough, you still owe me money." + Owe);
}else if(price < money) {
    document.write("You paid extra, here's your change." + Change);
}






// let money = 200,
// price = 400,
// change = money - price,
// moneyNeeded = price - money;
// if(money > price){
//     document.write("You paid extra, here's your change." + change);
// }else if(money == price){
//     document.write("You paid the exact amount, have a nice day!");
// }else if(price > money){
//     document.write("That's not enough, you still owe me money. " + moneyNeeded);
// }