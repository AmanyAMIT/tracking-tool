Factors to take into consideration:
__________________________________________

1- Don't use inline on enternal styles.
2- Use float property to develop this task.
3- Don't use px (to width, height, margins and padding). You can use % or vh.
4- Start use root, var and calc().