/*
    First Task: Write function that takes array of names and it should print 2 random names.
*/

// let names = document.getElementById('names');

// function Names() {
//     let randNames=['AMIT' , 'Learning', 'Fullstack' , 'Diploma'],
//     firstName = randNames[Math.floor(Math.random() * randNames.length)],
//     secondname= randNames[Math.floor(Math.random() * randNames.length)];
//     names.innerHTML = firstName + ' , ' + secondname;
// }

/* --------------------------------------------------------------------------------------------- */

/*
    Second Task: Write function that takes input from user and it returns how many times a letter was written in a sentence according to its index.
*/

let count = document.getElementById('count');

function Search() {
    let arr=[];
    let sentence = document.querySelector('.sentence').value;
    let letter = document.querySelector('.letter').value;
    for (n in sentence){
        if (sentence[n].toLowerCase() == letter.toLowerCase()){
            arr.push(n);
        }
    }
    count.innerHTML=arr;
}

