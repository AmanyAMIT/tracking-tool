// let Input = document.querySelector("input"),
//     One = document.querySelector(".one"),
//     Two = document.querySelector(".two"),
//     Three = document.querySelector(".three");

    
// function Check(){
//     One.classList.remove('ready');
//     Two.classList.remove('steady');
//     Three.classList.remove('go');
//     if(Input.value == 1){
//         One.classList.add('ready');
//     }else if(Input.value == 2){
//         Two.classList.add('steady');
//     }else if(Input.value == 3){
//         Three.classList.add('go');
//     }
//     console.log(Input.value);
// }

/* ---------------------------------------------- */

let Paragraph = document.querySelector("p"),
    Input = document.querySelector("input");

// function Convert(){
//     Paragraph.innerHTML=("<a href='https://www." + Input.value + ".com'>" + Input.value + "</a>");
// }

/* ---------------------------------------------- */

// confirm("Welcome to Who am I Game, Ready?");
// // Decleard Question Variables
let Question1 = "Are you fly ?";
let Question2 = "Are You Wild ?";
let Question3 = "Do you live under sea?";
//Start Frist Question
let fristRespond = prompt(Question1);
//Filter The Respond
fristRespond =  acceptableRespond(Question1,fristRespond);
if(fristRespond == "yes")
{
    //Start Second Question
    let secondRespond = prompt(Question2);
    //Filter The Respond
    secondRespond = acceptableRespond(Question2,secondRespond);
    if(secondRespond == "yes")
    {
        document.write("You are an Eagle");
        var img = document.createElement("img");
        img.src = "img/Eagle.PNG";
        var div = document.getElementById("x");
        div.appendChild(img);

    }else
    {
        document.write("You are a Parrot");
        var img = document.createElement("img");
        img.src = "img/Parrot.PNG";
        var div = document.getElementById("x");
        div.appendChild(img);

    }

}else
{
    //Start Second Question
    let secondRespond = prompt(Question3);
    //Filter The Respond
    secondRespond = acceptableRespond(Question3,secondRespond);
    if(secondRespond == "yes")
    {
        //Start Third Question
        let thirdRespond = prompt(Question2);
        //Filter The Respond
        thirdRespond = acceptableRespond(Question2,thirdRespond);
        if(thirdRespond == "yes")
        {
            document.write("You are a Shark");
            var img = document.createElement("img");
            img.src = "img/Shark.PNG";
            var div = document.getElementById("x");
            div.appendChild(img);
            
        }else
        {
            document.write("You are a Dolphin");
            var img = document.createElement("img");
            img.src = "img/Dolphin.PNG";
            var div = document.getElementById("x");
            div.appendChild(img);
        }

    }else
    {
        //Start Third Question
        let thirdRespond = prompt(Question2);
        //Filter The Respond
        thirdRespond = acceptableRespond(Question2,thirdRespond);
        if(thirdRespond == "yes")
        {
            document.write("You are a Lion");
            var img = document.createElement("img");
            img.src = "img/Lion.PNG";
            var div = document.getElementById("x");
            div.appendChild(img);
        }else
        {
            document.write("You are a Cat");
            var img = document.createElement("img");
            img.src = "img/Cat.PNG";
            var div = document.getElementById("x");
            div.appendChild(img);
        }
    }

}


// // Function to Filter the Respond from user 
function acceptableRespond(question,respond)
{
    respond = respond.toLowerCase();
    while(respond != "yes" && respond != "no")
    {
        respond = prompt("Please say Yes or No ! " + question);
        respond = respond.toLowerCase();
    }

    return respond;
}