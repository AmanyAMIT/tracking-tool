/* --------------------------------------------------------------------------------------------- */

/*
    Write function that takes an array of possible hex codes of colors and it should print any random hex code and display it to the <body>
    PS: You should use .style to add the color to the body as background-color
*/

// function ChangeColor(){
//         let hex_numbers = ["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"],
//         hex_code = '';
    
//         for(i = 0; i < 6; i++){
//             let random_code = Math.floor(Math.random() * hex_numbers.length);
//             hex_code += hex_numbers[random_code];
//         }
    
//         document.getElementsByTagName('body')[0].style.backgroundColor= "#" + hex_code;
//         document.querySelector(".hexcode").innerHTML = hex_code;
    
//     }

/* ----------------------------------------------------------------------------------------------- */

/*
    Toggle between dark and light modes
*/
let DarkMode = document.getElementById("dark"),
    LightMode = document.getElementById("light"),
    Body = document.getElementsByTagName("body")[0];

DarkMode.addEventListener("click" , ChangeMode);
function ChangeMode(){
    Body.classList.add("DarkBackground");
    LightMode.classList.remove("hide");
    DarkMode.classList.add("hide");
}
LightMode.addEventListener("click" , ChangeToLight);
function ChangeToLight(){
    Body.classList.remove("DarkBackground");
    LightMode.classList.add("hide");
    DarkMode.classList.remove("hide");
}

/* ------------------------------------------------------------------------------------------------ */

/*
    Write function that heighlights the bold words in a sentence
*/
// let BoldWords = document.getElementsByTagName("b"),
//     CountBoldWords = document.getElementById("BoldCount");

// function GetBoldWords(){
//     for(i = 0; i < BoldWords.length; i++){
//         BoldWords[i].classList.add("boldWords");
//         CountBoldWords.innerHTML = "The Total Number of Bold Words is: " + BoldWords.length
//     }
// }


/* ------------------------------------------------------------------------------------------------ */

/*
    Copy to Clipboard
*/

// let MyText = document.getElementById("MyText"),
// Success = document.getElementById("Success");

// function Copy(){
//     MyText.select();
//     MyText.setSelectionRange(0, 99999);
//     navigator.clipboard.writeText(MyText.value);
//     Success.classList.add("msg");
//     Success.innerHTML="Text Copied!";
// }

// function out(){
//         Success.classList.remove("msg");
//         Success.innerHTML="";
// }
