Factors to take into consideration:

1- Add comments in you code to make it more readable.
2- Use the alt attribute in img tag.
3- You need to search about <strong> and <cite> to develop this task.