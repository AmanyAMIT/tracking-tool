Factors to take into consideration:

1- Add comments in your code to make it more readable.
2- Don't use px, you can use % when you want to add width and vh when you want to add height.
3- Don't use inline or internal style.
4- You should use root to store the most used colors or font-sizes or any other properties into it.
5- Start using var and calc().
6- Develop this code by using flexbox properties.