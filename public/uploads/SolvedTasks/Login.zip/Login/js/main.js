const preloader = document.getElementById("preloader"),
    Username = document.getElementById("username"),
    Password = document.getElementById("password"),
    Submit = document.getElementById("submit");


    window.addEventListener("load", function () {
        preloader.style.display = "none";
    });

let attempt = 3; // Variable to count number of attempts.

// Below function Executes on click of login button.
function validate() {
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    if (username == "Formget" && password == "formget#123") {
    window.location = "success.html"; // Redirecting to other page.
    
    } else {

        attempt--; // Decrementing by one.
        Username.style.border = "1px solid red";
        Password.style.border = "1px solid red";
        alert("You have " + attempt + " attempt left");

        // Disabling fields after 3 attempts.
        if (attempt == 0) {
            Username.disabled = true;
            Password.disabled = true;
            Submit.disabled = true;
        }
    }
}