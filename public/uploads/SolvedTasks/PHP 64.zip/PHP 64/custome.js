// let Input = document.getElementById("input"),
//     Red = document.getElementById("red"),
//     Yellow = document.getElementById("yellow"),
//     Green = document.getElementById("green"),
//     Headings = document.getElementsByClassName("headings");



// function Light(){
//     for(let i = 0; i < Headings.length; i++) {
//         Headings[i].innerHTML="";
//     }
//     Red.classList.remove("one");
//     Yellow.classList.remove("two");
//     Green.classList.remove("three");
//     if(Input.value == 1) {
//         Red.classList.add("one");
//         Headings[0].innerHTML = "You can't go";
//     }else if(Input.value == 2) {
//         Yellow.classList.add("two");
//         Headings[1].innerHTML="Get ready";
//     }else if(Input.value == 3) {
//         Green.classList.add("three");
//         Headings[2].innerHTML="Go";
//     }
// }

/* ------------------------------------------------------ */

// let Input = document.getElementById("input"),
// Para = document.getElementById("demo");
// function Convert(){
//     Para.innerHTML= ("<a href='https://www." + Input.value + ".com'>" + Input.value + "</a>");
// }


/* ------------------------------------------------------ */
